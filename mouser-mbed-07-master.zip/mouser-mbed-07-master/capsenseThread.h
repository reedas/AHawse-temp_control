#ifndef CAPSENSE_THREAD_H
#define CAPSENSE_THREAD_H

void capsenseThread(void);

#endif
