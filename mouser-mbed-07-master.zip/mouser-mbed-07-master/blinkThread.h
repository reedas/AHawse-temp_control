#ifndef BLINK_THREAD_H
#define BLINK_THREAD_H

void blinkThread();

#endif
