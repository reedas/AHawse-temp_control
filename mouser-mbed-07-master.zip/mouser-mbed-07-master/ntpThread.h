#ifndef NTP_THREAD_H
#define NTP_THREAD_H
void ntpThread();

#endif
